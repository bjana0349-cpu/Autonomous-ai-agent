# Jarvis Android Build and Diagnosis

## Access limitation

The user's actual Termux path `~/jarvis-build/autonomous-ai-agent/android-jarvis` is not mounted in this execution environment. The sandbox also does not contain the user's `$HOME/android-sdk`, Termux `aapt2`, or `build-error.txt`. Therefore the phone's earliest AAPT2/root-cause error and on-device APK build cannot honestly be reported from here.

The existing repository copy was inspected and preserved. No phone-local files were claimed to be edited.

## Run diagnostics on the actual Termux phone

From the repository root:

```bash
cd "$HOME/jarvis-build/autonomous-ai-agent"
bash termux/diagnose-android-build.sh | tee build-diagnostics.txt
```

This is non-destructive. Send the resulting `build-diagnostics.txt` and the complete `build-error.txt` if you want the exact earliest root cause diagnosed.

## On-device build attempt

First verify the architecture and tools:

```bash
uname -m
java -version
gradle --version
file "$(command -v aapt2)"
file "$HOME/android-sdk/platforms/android-35/android.jar"
```

Then build without deleting caches:

```bash
cd "$HOME/jarvis-build/autonomous-ai-agent/android-jarvis"
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$HOME/android-sdk"
gradle --no-daemon --stacktrace :app:assembleDebug 2>&1 | tee build-error.txt
```

If AAPT2 is x86-64 on an ARM64 phone, do not execute it and do not solve this by blindly setting `android.aapt2FromMavenOverride`. Use the cloud workflow below instead, or obtain a verified supported ARM64-compatible Android build toolchain.

## Reproducible cloud build

The repository now includes:

```text
.github/workflows/android-jarvis.yml
```

Push the existing repository to GitHub, then run:

```text
GitHub → Actions → Android Jarvis Debug APK → Run workflow
```

The workflow uses an official Ubuntu x86-64 runner with:

- Java 17
- Gradle 8.9, compatible with Android Gradle Plugin 8.7.3
- Android platform 35
- Build tools 35.0.0

It verifies that the APK is non-empty and uploads the debug APK as the `jarvis-debug-apk` artifact.

Download the artifact from the completed GitHub Actions run, then on Termux:

```bash
termux-setup-storage
cp "$HOME/storage/downloads/app-debug.apk" "$HOME/"
```

Install through Android's package installer or use ADB from a computer:

```bash
adb install -r app-debug.apk
```

## Build result status in this environment

- Existing Python agent regression: passed.
- Jarvis source/configuration static checks: passed.
- Android APK build: not run because Gradle, Android SDK, ADB, and `javac` are unavailable in this sandbox.
- Real Android installation: not run because no Android device is attached.
- Screen-off microphone test: not run because no target phone is attached.
- AAPT2 root cause: cannot be determined without the user's actual `build-error.txt` and Termux SDK binaries.
