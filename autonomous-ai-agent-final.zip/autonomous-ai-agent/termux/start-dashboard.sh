#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
export AGENT_DASHBOARD_START_WORKER=0
exec "$PYTHON" "$APP_DIR/main.py" dashboard --host "$AGENT_DASHBOARD_HOST" --port "$AGENT_DASHBOARD_PORT"
