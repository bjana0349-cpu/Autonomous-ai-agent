#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
exec "$PYTHON" "$APP_DIR/main.py" bridge --host "$AGENT_BRIDGE_HOST" --port "$AGENT_BRIDGE_PORT"
