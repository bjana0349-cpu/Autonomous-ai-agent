#!/data/data/com.termux/files/usr/bin/bash
set -u
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../android-jarvis" && pwd)"
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
printf '%s\n' '=== Jarvis Termux Android build diagnostics ==='
printf 'app_dir=%s\n' "$APP_DIR"
printf 'termux_arch='; uname -m
printf 'java='; command -v java || true
java -version 2>&1 | head -n 3 || true
printf 'gradle='; command -v gradle || true
gradle --version 2>&1 | head -n 8 || true
printf 'sdk_root=%s\n' "$SDK_ROOT"
printf 'aapt2='; command -v aapt2 || true
if command -v aapt2 >/dev/null 2>&1; then file "$(command -v aapt2)"; fi
printf 'android_jar='; if [ -f "$SDK_ROOT/platforms/android-35/android.jar" ]; then echo "$SDK_ROOT/platforms/android-35/android.jar"; file "$SDK_ROOT/platforms/android-35/android.jar"; else echo MISSING; fi
printf '%s\n' '--- SDK directories ---'
find "$SDK_ROOT/platforms" "$SDK_ROOT/build-tools" -maxdepth 2 -type f -name android.jar -o -name aapt2 2>/dev/null | sort || true
printf '%s\n' '--- project files ---'
find "$APP_DIR" -maxdepth 4 -type f | sort
printf '%s\n' '--- build-error files ---'
find "$HOME/jarvis-build" "$APP_DIR" -maxdepth 3 -type f \( -name 'build-error.txt' -o -name '*error*.log' \) -print 2>/dev/null || true
printf '%s\n' '=== Diagnostics complete; no files were modified ==='
