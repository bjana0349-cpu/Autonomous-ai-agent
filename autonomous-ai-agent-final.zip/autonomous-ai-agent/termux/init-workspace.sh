#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
mkdir -p "$AGENT_DATA_ROOT"/{tasks,logs,checkpoints,reports,memory} "$AGENT_PROJECT_ROOT" "$AGENT_BRIDGE_WORKSPACE"
python3 -m compileall -q "$APP_DIR"
[ -f "$ENV_FILE" ] && echo "Environment: $ENV_FILE"
echo "Workspace initialized"
echo "Data: $AGENT_DATA_ROOT"
echo "Projects: $AGENT_PROJECT_ROOT"
echo "Bridge: $AGENT_BRIDGE_WORKSPACE"
