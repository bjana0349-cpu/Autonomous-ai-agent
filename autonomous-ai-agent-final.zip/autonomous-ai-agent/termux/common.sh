#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${AGENT_ENV_FILE:-$APP_DIR/.env}"
if [ -f "$ENV_FILE" ]; then set -a; . "$ENV_FILE"; set +a; fi
export AGENT_DATA_ROOT="${AGENT_DATA_ROOT:-$HOME/autonomous-agent-workspace/data}"
export AGENT_PROJECT_ROOT="${AGENT_PROJECT_ROOT:-$HOME/autonomous-agent-workspace/projects}"
export AGENT_BRIDGE_WORKSPACE="${AGENT_BRIDGE_WORKSPACE:-$AGENT_PROJECT_ROOT}"
export AGENT_DASHBOARD_HOST="${AGENT_DASHBOARD_HOST:-127.0.0.1}"
export AGENT_DASHBOARD_PORT="${AGENT_DASHBOARD_PORT:-8080}"
export AGENT_BRIDGE_HOST="${AGENT_BRIDGE_HOST:-127.0.0.1}"
export AGENT_BRIDGE_PORT="${AGENT_BRIDGE_PORT:-8765}"
mkdir -p "$AGENT_DATA_ROOT" "$AGENT_PROJECT_ROOT" "$AGENT_BRIDGE_WORKSPACE"
cd "$APP_DIR"
PYTHON="${PYTHON:-python3}"
PYTHON="$PYTHON"
