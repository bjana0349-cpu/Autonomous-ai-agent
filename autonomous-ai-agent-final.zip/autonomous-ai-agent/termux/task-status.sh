#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
if [ "$#" -gt 0 ]; then exec "$PYTHON" "$APP_DIR/main.py" status "$1"; else exec "$PYTHON" "$APP_DIR/main.py" status; fi
