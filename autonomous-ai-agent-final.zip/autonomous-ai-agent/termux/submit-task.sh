#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
[ "$#" -gt 0 ] || { echo "Usage: $0 \"task request\"" >&2; exit 2; }
exec "$PYTHON" "$APP_DIR/main.py" submit "$*"
