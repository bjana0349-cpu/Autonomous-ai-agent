#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if command -v pkg >/dev/null 2>&1; then
  pkg update -y
  pkg install -y python git nodejs
else
  echo "pkg not found; continuing in non-Termux simulation mode" >&2
fi
if [ ! -f "$APP_DIR/.env" ]; then cp "$APP_DIR/.env.example" "$APP_DIR/.env"; fi
set -a; . "$APP_DIR/.env"; set +a
: "${AGENT_DATA_ROOT:=$HOME/autonomous-agent-workspace/data}"
: "${AGENT_PROJECT_ROOT:=$HOME/autonomous-agent-workspace/projects}"
: "${AGENT_BRIDGE_WORKSPACE:=$AGENT_PROJECT_ROOT}"
mkdir -p "$AGENT_DATA_ROOT" "$AGENT_PROJECT_ROOT" "$AGENT_BRIDGE_WORKSPACE"
if [ -z "${BRIDGE_TOKEN:-}" ] || [ "$BRIDGE_TOKEN" = replace-with-a-long-random-token ]; then
  token=$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')
  if grep -q '^BRIDGE_TOKEN=' "$APP_DIR/.env"; then sed -i "s|^BRIDGE_TOKEN=.*|BRIDGE_TOKEN=$token|" "$APP_DIR/.env"; else printf '\nBRIDGE_TOKEN=%s\n' "$token" >> "$APP_DIR/.env"; fi
fi
python3 -m compileall -q "$APP_DIR"
chmod +x "$APP_DIR"/termux/*.sh
echo "Installed: $APP_DIR"
echo "Data root: $AGENT_DATA_ROOT"
echo "Project root: $AGENT_PROJECT_ROOT"
echo "Run: $APP_DIR/termux/init-workspace.sh"
