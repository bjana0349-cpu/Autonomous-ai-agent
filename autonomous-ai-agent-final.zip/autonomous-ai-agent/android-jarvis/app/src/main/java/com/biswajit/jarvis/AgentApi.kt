package com.biswajit.jarvis

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AgentApi(private val baseUrl: String, private val client: OkHttpClient = OkHttpClient()) {
    fun submit(request: String, callback: (String?, String?) -> Unit) {
        val body = RequestBody.create("application/json".toMediaType(), JSONObject().put("request", request).toString())
        client.newCall(Request.Builder().url("$baseUrl/api/tasks").post(body).build()).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) = callback(null, e.message)
            override fun onResponse(call: Call, response: Response) { response.use { val text=it.body?.string().orEmpty(); if(!it.isSuccessful) callback(null,"HTTP ${it.code}") else try { callback(JSONObject(text).optString("task_id"),null) } catch(e:Exception){ callback(null,e.message) } } }
        })
    }
    fun list(callback: (JSONArray?, String?) -> Unit) {
        client.newCall(Request.Builder().url("$baseUrl/api/tasks").get().build()).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) = callback(null,e.message)
            override fun onResponse(call: Call, response: Response) { response.use { val text=it.body?.string().orEmpty(); if(!it.isSuccessful) callback(null,"HTTP ${it.code}") else try { callback(JSONArray(text),null) } catch(e:Exception){ callback(null,e.message) } } }
        })
    }
}
