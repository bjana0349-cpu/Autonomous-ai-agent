package com.biswajit.jarvis

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    private val prefs by lazy { getSharedPreferences("jarvis", 0) }
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { history.append("\n${i.getStringExtra("text").orEmpty()}") } }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, IntentFilter("JARVIS_EVENT"), RECEIVER_NOT_EXPORTED) else registerReceiver(receiver, IntentFilter("JARVIS_EVENT")); buildUi(); requestPermissionsIfNeeded() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        status = TextView(this).apply { text = "Jarvis stopped"; textSize = 20f }
        history = TextView(this).apply { text = "Conversation history"; textSize = 16f }
        val start = Button(this).apply { text = "Start Listening"; setOnClickListener { ContextCompat.startForegroundService(this@MainActivity, Intent(this@MainActivity, VoiceAssistantService::class.java).setAction("START")); status.text = "Listening for Jarvis…" } }
        val stop = Button(this).apply { text = "Stop Listening"; setOnClickListener { stopService(Intent(this@MainActivity, VoiceAssistantService::class.java)); status.text = "Jarvis stopped" } }
        val interrupt = Button(this).apply { text = "Interrupt Speech"; setOnClickListener { startService(Intent(this@MainActivity, VoiceAssistantService::class.java).setAction("INTERRUPT")) } }
        val settings = EditText(this).apply { hint = "Backend URL"; setText(prefs.getString("backend", "http://127.0.0.1:8080")); setOnFocusChangeListener { _, has -> if (!has) prefs.edit().putString("backend",text.toString().trimEnd('/')).apply() } }
        val enroll = Button(this).apply { text = "Owner enrollment (optional)"; setOnClickListener { Toast.makeText(this@MainActivity,"Voice matching is not authentication; sensitive actions require device confirmation.",Toast.LENGTH_LONG).show() } }
        root.addView(status); root.addView(start); root.addView(stop); root.addView(interrupt); root.addView(settings); root.addView(enroll); root.addView(history); setContentView(root)
    }
    private fun requestPermissionsIfNeeded() { val missing = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS).filter { ContextCompat.checkSelfPermission(this,it) != PackageManager.PERMISSION_GRANTED }; if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 42) }
    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}
