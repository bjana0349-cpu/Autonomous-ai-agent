package com.biswajit.jarvis

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.*

class VoiceAssistantService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    private lateinit var recognizer: SpeechRecognizer; private lateinit var tts: TextToSpeech; private var commandMode = false; private var lastTask: String? = null
    private val api by lazy { AgentApi(getSharedPreferences("jarvis",0).getString("backend","http://127.0.0.1:8080")!!) }
    override fun onCreate() { super.onCreate(); createChannel(); startForeground(7, notification("Listening for Jarvis")); tts=TextToSpeech(this,this); recognizer=SpeechRecognizer.createSpeechRecognizer(this); recognizer.setRecognitionListener(this); listen() }
    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int { if (i?.action=="INTERRUPT") { tts.stop(); commandMode=false; listen() }; return START_STICKY }
    private fun listen() { val r=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3) }; Handler(Looper.getMainLooper()).postDelayed({ try { recognizer.startListening(r) } catch (_: Exception) {} },300) }
    override fun onResults(b: Bundle) { val text=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); if (text.isNotBlank()) handle(text); else listen() }
    private fun handle(raw: String) { val text=raw.trim(); val lower=text.lowercase(Locale.ROOT); if (!commandMode) { if (!lower.contains("jarvis")) { listen(); return }; commandMode=true; speak("Hi Biswajit, ami ki bhabe sahajjo korte pari?"); val after=lower.substringAfter("jarvis").trim(); if (after.isNotEmpty()) submit(after); else listen() } else { commandMode=false; submit(text) } }
    private fun submit(request: String) { broadcast("You: $request"); api.submit(request) { id,error -> Handler(Looper.getMainLooper()).post { if (error!=null) speak("Dukkhito, agent-er sathe jogajog hoyni.") else { lastTask=id; speak("Task submit korechi."); broadcast("Task: $id"); pollStatus(id.orEmpty()) } } } }
    private fun pollStatus(id:String) { if(id.isEmpty()) return; api.list { rows,_ -> Handler(Looper.getMainLooper()).post { for(i in 0 until (rows?.length() ?: 0)) { val t=rows?.optJSONObject(i) ?: continue; if(t.optString("task_id")==id) { val s=t.optString("status"); broadcast("Status: $s"); if(s !in setOf("COMPLETED","FAILED","CANCELLED")) Handler(Looper.getMainLooper()).postDelayed({ pollStatus(id) },4000) else speak(if(s=="COMPLETED") "Task shesh hoyeche." else "Task-er obostha $s."); break } } } } }
    private fun speak(text: String) { broadcast("Jarvis: $text"); tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis") }
    private fun broadcast(text:String) { sendBroadcast(Intent("JARVIS_EVENT").putExtra("text",text)) }
    private fun notification(text:String)=NotificationCompat.Builder(this,"jarvis").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Jarvis microphone").setContentText(text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_SERVICE).build()
    private fun createChannel() { if (Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("jarvis","Jarvis microphone",NotificationManager.IMPORTANCE_LOW)) }
    override fun onInit(status:Int) { if (status==TextToSpeech.SUCCESS) tts.language=Locale("bn","BD") }
    override fun onDestroy() { recognizer.destroy(); tts.shutdown(); super.onDestroy() }
    override fun onBind(i:Intent?)=null
    override fun onReadyForSpeech(p:Bundle?){}; override fun onBeginningOfSpeech(){}; override fun onRmsChanged(r:Float){}; override fun onBufferReceived(b:ByteArray?){}; override fun onEndOfSpeech(){ listen() }; override fun onError(e:Int){ listen() }; override fun onPartialResults(b:Bundle?){ }; override fun onEvent(t:Int,p:Bundle?){ }
}
