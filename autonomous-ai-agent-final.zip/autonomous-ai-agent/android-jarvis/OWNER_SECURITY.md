# Owner and sensitive-action policy

Jarvis treats wake-word recognition and any optional voice enrollment as convenience features only. A voice match is **not** authentication.

The current Android module requires a separate device-authentication/confirmation flow before adding sensitive actions. It does not execute arbitrary shell commands from voice input. Voice requests are sent only to the existing agent task-submission API, where the agent's command classification and approval workflow remain authoritative.

A production speaker-verification model (for example, an on-device TFLite embedding model) is intentionally not bundled yet because it requires a selected model, enrollment UX, false-accept testing, and target-device evaluation. Do not present the optional enrollment button as security.
