# Android Termux Deployment

This guide runs the existing assistant on Android without assuming `/home/ubuntu`. The application can live anywhere; the recommended layout is:

```text
$HOME/autonomous-ai-agent/                 application
$HOME/autonomous-agent-workspace/data/     SQLite, tasks, logs, checkpoints, reports
$HOME/autonomous-agent-workspace/projects/ generated user projects
```

## 1. Install in Termux

```bash
pkg update -y
pkg install -y git python nodejs
cd "$HOME"
git clone <YOUR_REPOSITORY_URL> autonomous-ai-agent
cd "$HOME/autonomous-ai-agent"
bash termux/install.sh
bash termux/init-workspace.sh
```

If the repository was copied to the phone instead of cloned, run the same two scripts from its directory. `install.sh` creates `.env` from `.env.example`, generates a bridge token if needed, creates workspace directories, and compiles Python files.

## 2. Configure the model

Edit the generated file:

```bash
nano "$HOME/autonomous-ai-agent/.env"
```

Required values:

```bash
OPENAI_API_KEY=your-key
OPENAI_API_BASE=https://api.openai.com/v1
AGENT_MODEL=gpt-5-mini
BRIDGE_TOKEN=long-random-secret
```

The default paths are expanded from `$HOME`; do not replace them with `/home/ubuntu`.

## 3. Start services

Use separate Termux sessions. Keep the worker running even when the dashboard is closed.

```bash
cd "$HOME/autonomous-ai-agent"
bash termux/start-worker.sh
```

```bash
cd "$HOME/autonomous-ai-agent"
bash termux/start-dashboard.sh
```

```bash
cd "$HOME/autonomous-ai-agent"
bash termux/start-bridge.sh
```

Default addresses:

- Dashboard: `http://127.0.0.1:8080`
- Bridge: `http://127.0.0.1:8765`

To access the dashboard from another device on the same network, set `AGENT_DASHBOARD_HOST=0.0.0.0` and use the phone's LAN IP. Keep the bridge on `127.0.0.1` unless it is placed behind appropriate network security.

## 4. Submit and control tasks

```bash
bash termux/submit-task.sh "Build a small professional grocery store website"
bash termux/task-status.sh TASK_ID
bash termux/pause-task.sh TASK_ID
bash termux/resume-task.sh TASK_ID
bash termux/stop-task.sh TASK_ID
```

List all tasks:

```bash
bash termux/task-status.sh
```

The dashboard provides the same controls plus live events, terminal output, errors, automatic fixes, approval controls, and progress.

## 5. Recover after Android or Termux restart

First reinitialize directories and explicitly release stale worker locks:

```bash
bash termux/init-workspace.sh
bash termux/recover-tasks.sh
bash termux/start-worker.sh
```

The worker also calls recovery automatically at startup. Unfinished `PLANNING`, `RUNNING`, `TESTING`, and `DEBUGGING` tasks are re-enqueued from their persistent task state/checkpoint rather than recreated from scratch.

## 6. Bridge security

The bridge is workspace-confined to `AGENT_BRIDGE_WORKSPACE`. It requires:

```bash
curl -H "Authorization: Bearer $BRIDGE_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"op":"status"}' \
  "http://127.0.0.1:${AGENT_BRIDGE_PORT:-8765}/"
```

Never set the bridge workspace to `$HOME`, `/`, or the whole shared Android storage directory. The command policy denies dangerous commands and the path policy rejects traversal, absolute escapes, and symlink escapes.

## 7. Environment variables

See `.env.example` for the complete list:

- `AGENT_DATA_ROOT`
- `AGENT_PROJECT_ROOT`
- `AGENT_BRIDGE_WORKSPACE`
- `OPENAI_API_KEY`
- `OPENAI_API_BASE`
- `AGENT_MODEL`
- `BRIDGE_TOKEN`
- dashboard and bridge host/port values
- model retry, task iteration, task runtime, command runtime, and context limits

## 8. Termux limitations

Android may suspend background processes. For long-running work, exclude Termux from battery optimization and consider Termux:WakeLock. The local dashboard and bridge are not a hosted public service. SQLite is intended for one local worker; multi-device deployments should use a secured server and a shared database/queue.
