# Android Termux Deployment QA

Date: 2026-10-08

## Environment

A clean copy of the repository was installed under:

```text
/tmp/termux-like-qa/home/autonomous-ai-agent
```

The simulated Termux home was:

```text
/tmp/termux-like-qa/home
```

The configured runtime roots were:

```text
/tmp/termux-like-qa/home/autonomous-agent-workspace/data
/tmp/termux-like-qa/home/autonomous-agent-workspace/projects
```

No `/home/ubuntu` path was used by the Termux scripts.

## Passed checks

- `termux/install.sh` ran successfully in non-Termux simulation mode and correctly skipped `pkg` only because the simulator did not provide it.
- `termux/init-workspace.sh` created data, project, and bridge directories.
- Python compilation passed.
- Bash syntax validation passed for every Termux script.
- Worker started independently.
- Dashboard started independently without creating a duplicate worker.
- Bridge started independently on port `19765`.
- Dashboard served successfully on port `19080`.
- Unauthenticated bridge request returned HTTP 401.
- Termux submit wrapper created a persistent SQLite task and task JSON state.
- Normal explicit website task completed in the configured project root.
- Model-backed broken-JavaScript task completed with `retry_count: 1`.
- The repair task produced logs, a checkpoint, and a final report.
- The restart recovery task was interrupted while `TESTING`, the worker was terminated, `recover-tasks.sh` was run, and the replacement worker resumed the task to `COMPLETED`.
- Bridge registration passed.
- Bridge heartbeat passed.
- Authenticated bridge command execution passed with exit code `0`.
- Workspace escape request `../../etc/passwd` returned HTTP 400.
- Dashboard remained available while the standalone worker was running.
- Dashboard approval-to-resume endpoint was exercised against a model-submitted task.

## Persistent recovery evidence

The successful recovery task was:

```text
termux_recovery4
```

It was observed in `TESTING`, the worker process was hard-terminated, the task state remained persisted, and after `recover-tasks.sh` plus worker restart it reached `COMPLETED` with a checkpoint.

## Model and submitted-task observations

The Termux CLI submission path was exercised with a simple website request. The configured model produced a plan that requested approval and the task was observed in `WAITING_APPROVAL`; the approval endpoint was then exercised. A separate explicit normal task and explicit broken-JavaScript task were used to verify deterministic execution and automatic repair independently of model-plan quality.

This is intentional evidence rather than a hidden failure: the deployment layer, queue, approval path, worker, repair loop, persistence, and security boundary all behaved as designed, while model-generated plans remain subject to model availability and plan quality.

## Known Termux limitations

- Android may suspend Termux processes; users should exclude Termux from battery optimization and may use Termux:WakeLock for long tasks.
- The bridge defaults to loopback. Exposing it beyond the phone requires additional network and TLS controls.
- SQLite is designed for one local worker. Multi-worker deployments should use a shared database/queue.
- The local model API must be configured in `.env`; no API key is stored in the repository.
