import argparse,json,os
from pathlib import Path
from agent.models import TaskState
from agent.storage import Storage
from agent.loop import AgentLoop
from agent.worker import Worker

def self_test(root):
    s=Storage(root); t=TaskState.new('Create a responsive website with homepage, navigation, contact form and footer','selftest_autonomous'); t.plan=[{'title':'Create page','kind':'write','path':'index.html','content':'<!doctype html><html><body><nav>Home</nav><main><h1>Shop</h1><form><input name="email"></form></main><footer>Footer</footer><script src="app.js"></script></body></html>'},{'title':'Create script','kind':'write','path':'app.js','content':'document.querySelector("form").addEventListener("submit", function(e) { e.preventDefault(); console.log("ok"); }'}, {'title':'Create test','kind':'write','path':'tests/test_site.py','content':'from pathlib import Path\nimport unittest\nclass SiteTest(unittest.TestCase):\n def test_parts(self):\n  html=Path("index.html").read_text(); self.assertIn("<footer>",html); self.assertIn("</script>",html); self.assertIn("});",Path("app.js").read_text())\nif __name__=="__main__": unittest.main()'},{'title':'Run verification','kind':'test','command':'python -m unittest discover -s tests -v'}]; s.save(t); loop=AgentLoop(root,s); loop.planner.plan=lambda request:{'steps':t.plan}; out=loop.run(t); events=[e.get('event_type') for e in out.events]; return {'status':out.status,'retry_count':out.retry_count,'error_detected':'error_detected' in events,'error_analyzed':'error_detected' in events,'repair_applied':any(e.get('event_type')=='fix_attempted' and e.get('fixed') for e in out.events),'final_test_passed':out.status=='COMPLETED','model_repair_used':any(e.get('mode')=='model' for e in out.events),'checkpoint_exists':(root/'checkpoints'/f'{t.task_id}.json').exists(),'project_dir':out.project_dir}

def main():
    p=argparse.ArgumentParser(); p.add_argument('command',choices=['self-test','submit','worker','resume','stop','pause','retry','status','recover','dashboard','bridge']); p.add_argument('value',nargs='?'); p.add_argument('--host',default=None); p.add_argument('--port',type=int,default=None); a=p.parse_args(); root=Path(__file__).resolve().parent; data_root=Path(os.getenv('AGENT_DATA_ROOT',str(root))).expanduser(); s=Storage(data_root)
    if a.command=='self-test': print(json.dumps(self_test(root),indent=2)); return
    if a.command=='submit':
        t=TaskState.new(a.value or 'Build a small website'); s.save(t); s.enqueue(t.task_id); print(json.dumps({'task_id':t.task_id,'status':'QUEUED'})); return
    if a.command=='worker':
        w=Worker(root,s); w.start(); print('Worker running; press Ctrl-C to stop.')
        try:
            import time
            while True: time.sleep(1)
        except KeyboardInterrupt: w.stop()
        return
    if a.command=='status':
        if not a.value: print(json.dumps([t.to_dict() for t in s.list_tasks()],indent=2))
        else: print(json.dumps(s.load(a.value).to_dict(),indent=2))
        return
    if a.command=='recover':
        s.recover_stale(); print(json.dumps({'recovered':True,'data_root':str(data_root)})); return
    if a.command in ('resume','stop','pause','retry'):
        loop=AgentLoop(root,s); t=loop.resume_task(a.value) if a.command=='resume' else loop.request_control(a.value,{'stop':'CANCEL','pause':'PAUSE','retry':'RUN'}[a.command]);
        if a.command=='retry': t.status='QUEUED'; s.save(t); s.enqueue(t.task_id)
        print(json.dumps(t.to_dict(),indent=2)); return
    if a.command=='dashboard':
        from dashboard.server import serve; serve(root,a.host or os.getenv('AGENT_DASHBOARD_HOST','127.0.0.1'),a.port or int(os.getenv('AGENT_DASHBOARD_PORT','8080')),data_root)
    else:
        from terminal_bridge.server import serve; serve(Path(os.getenv('AGENT_BRIDGE_WORKSPACE',os.getenv('AGENT_PROJECT_ROOT',str(data_root/'projects')))).expanduser(),a.host or os.getenv('AGENT_BRIDGE_HOST','127.0.0.1'),a.port or int(os.getenv('AGENT_BRIDGE_PORT','8765')))
if __name__=='__main__': main()
