import os,json,urllib.request
class ModelAdapter:
    def __init__(self): self.key=os.getenv('OPENAI_API_KEY'); self.base=os.getenv('OPENAI_API_BASE','https://api.openai.com/v1').rstrip('/'); self.model=os.getenv('AGENT_MODEL','gpt-5-mini')
    def json_call(self,system,user):
        if not self.key: return None
        body={'model':self.model,'temperature':0.1,'messages':[{'role':'system','content':system},{'role':'user','content':user}]}
        req=urllib.request.Request(self.base+'/chat/completions',data=json.dumps(body).encode(),headers={'Authorization':'Bearer '+self.key,'Content-Type':'application/json'})
        raw=json.loads(urllib.request.urlopen(req,timeout=30).read()); text=raw['choices'][0]['message']['content']; start=text.find('{'); end=text.rfind('}');
        if start<0 or end<start: raise ValueError('Model did not return JSON')
        return json.loads(text[start:end+1])
class Planner:
    def __init__(self): self.model=ModelAdapter()
    def plan(self,request):
        result=None
        try: result=self.model.json_call('Return only JSON with project_name and steps. Each step has title and kind write or test; write uses path/content, test uses command. Keep commands workspace-relative and safe.',request)
        except Exception: pass
        if result and result.get('steps'): return result
        return {'project_name':'generated-site','steps':[{'title':'Create responsive site','kind':'write','path':'index.html','content':'<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Generated Site</title></head><body><main><h1>Welcome</h1><p>Built autonomously.</p></main></body></html>'},{'title':'Create regression test','kind':'write','path':'tests/test_site.py','content':'from pathlib import Path\nimport unittest\nclass SiteTest(unittest.TestCase):\n def test_page(self): self.assertIn("<main>", Path("index.html").read_text())\nif __name__ == "__main__": unittest.main()'},{'title':'Run tests','kind':'test','command':'python -m unittest discover -s tests -v'}]}
