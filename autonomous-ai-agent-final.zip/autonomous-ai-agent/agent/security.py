import shlex
from pathlib import Path
class SecurityError(Exception): pass
class WorkspacePolicy:
    SAFE={'python','python3','node','npm','git','pytest','touch','mkdir','ls','pwd','cat','grep','find','sh','test'}
    RESTRICTED={'pip','pip3','rm','mv','cp'}
    DANGEROUS={'sudo','su','chmod','chown','mkfs','dd','shutdown','reboot','kill','format'}
    def __init__(self,workspace,timeout=30): self.workspace=Path(workspace).resolve(); self.timeout=timeout
    def path(self,rel):
        p=(self.workspace/rel).resolve()
        if p!=self.workspace and self.workspace not in p.parents: raise SecurityError('Path escapes designated workspace')
        return p
    def classify(self,c):
        parts=shlex.split(c); root=Path(parts[0]).name if parts else ''
        if not parts or root in self.DANGEROUS: return 'DANGEROUS'
        if root in self.RESTRICTED: return 'RESTRICTED'
        return 'SAFE' if root in self.SAFE else 'DANGEROUS'
    def command(self,c,allow_restricted=False,allow_approval=False):
        kind=self.classify(c)
        if (kind=='DANGEROUS' and not allow_approval) or (kind=='RESTRICTED' and not (allow_restricted or allow_approval)): raise SecurityError(f'Command requires approval: {kind}')
        if any(x in c for x in ('&&','||',';','|','`','$(')): raise SecurityError('Shell chaining/substitution is not permitted')
        return kind
