class ErrorAnalyzer:
 def analyze(self,r): return {'summary':(r.get('stdout','')+'\n'+r.get('stderr','')).strip()[-4000:] or 'Command failed without output','exit_code':r.get('exit_code'),'likely_cause':'Test or command failure; inspect output and apply a scoped repair.'}
