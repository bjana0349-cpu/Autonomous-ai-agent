import json,re
class Fixer:
    def __init__(self,model): self.model=model
    def fix(self,analysis,term,task):
        relevant={}
        for rel in (task.files_created+task.files_modified):
            try: relevant[rel]=term.read(rel)[:16000]
            except Exception: pass
        try:
            result=self.model.json_call('Return only JSON {"edits":[{"path":string,"content":string}],"summary":string}. Repair the reported error with minimal relevant edits. Do not include explanations outside JSON.',json.dumps({'error':analysis.get('summary',''),'files':relevant,'request':task.request}))
            if result and result.get('edits'):
                for edit in result['edits']: term.write(edit['path'],edit['content']); task.files_modified.append(edit['path'])
                return {'fixed':True,'description':result.get('summary','Model repair applied'),'mode':'model'}
        except Exception: pass
        match=re.search(r'File "([^"]+)", line (\d+)',analysis.get('summary',''))
        if match:
            path=match.group(1)
            try:
                rel=path.split(str(term.policy.workspace)+'/')[-1]; text=term.read(rel); fixed=text.replace('\\x00','')
                if fixed!=text: term.write(rel,fixed); task.files_modified.append(rel); return {'fixed':True,'description':'Removed invalid source byte reported by the interpreter.','mode':'generic'}
            except Exception: pass
        return {'fixed':False,'description':'No model or generic repair could be safely applied.','mode':'none'}
