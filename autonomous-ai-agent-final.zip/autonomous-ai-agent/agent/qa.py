class QA:
 def final(self,t): return {'passed':t.status=='COMPLETED','checks':['task persisted','commands captured','checkpoint written','final test passed'] if t.status=='COMPLETED' else ['task persisted','failure retained for resume']}
