import subprocess,time,os,signal
from .security import WorkspacePolicy
class Terminal:
    def __init__(self,w,timeout=None): self.policy=WorkspacePolicy(w,timeout or int(os.getenv('MAX_COMMAND_RUNTIME','120'))); self.process=None
    def run(self,c,cwd='.',allow_restricted=False,allow_approval=False,cancel=None):
        kind=self.policy.command(c,allow_restricted,allow_approval); started=time.time()
        self.process=subprocess.Popen(c,shell=True,cwd=str(self.policy.path(cwd)),text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        while self.process.poll() is None:
            if cancel and cancel(): os.killpg(self.process.pid,signal.SIGTERM); return {'command':c,'stdout':'','stderr':'CANCELLED','exit_code':130,'classification':kind,'cancelled':True,'duration_ms':round((time.time()-started)*1000)}
            if time.time()-started>self.policy.timeout: os.killpg(self.process.pid,signal.SIGTERM); return {'command':c,'stdout':'','stderr':'TIMEOUT','exit_code':124,'classification':kind,'timeout':True,'duration_ms':round((time.time()-started)*1000)}
            time.sleep(.05)
        out,err=self.process.communicate(); return {'command':c,'stdout':out[-12000:],'stderr':err[-12000:],'exit_code':self.process.returncode,'classification':kind,'duration_ms':round((time.time()-started)*1000)}
    def write(self,r,content):
        p=self.policy.path(r); p.parent.mkdir(parents=True,exist_ok=True); existed=p.exists(); p.write_text(content); return 'modified' if existed else 'created'
    def read(self,r): return self.policy.path(r).read_text()
    def delete(self,r): self.policy.path(r).unlink(); return True
