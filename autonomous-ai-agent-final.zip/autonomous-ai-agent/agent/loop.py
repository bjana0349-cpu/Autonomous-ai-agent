import time, os
from pathlib import Path
from .planner import Planner
from .terminal import Terminal
from .error_analyzer import ErrorAnalyzer
from .fixer import Fixer
from .qa import QA
from .security import SecurityError
class AgentLoop:
    def __init__(self,root,storage): self.root=root; self.storage=storage; self.project_root=Path(os.getenv('AGENT_PROJECT_ROOT',str(Path(root)/'projects'))).expanduser(); self.planner=Planner(); self.analyzer=ErrorAnalyzer(); self.fixer=Fixer(self.planner.model); self.active={}
    def emit(self,t,event,**data): t.events.append(self.storage.log(t.task_id,event,**data)); self.storage.save(t)
    def state(self,t,status,action=''):
        t.status=status; t.current_action=action; self.emit(t,'state_changed',status=status,action=action)
    def cancel_requested(self,t): return t.control in ('CANCEL','PAUSE')
    def run(self,t,intentional_bug=False):
        started=time.time(); t.started_at=t.started_at or __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(); self.active[t.task_id]=t
        try:
            if not t.plan:
                self.state(t,'PLANNING','Planning task'); plan=self.planner.plan(t.request); t.plan=plan['steps']; t.total_steps=len(t.plan); t.project_dir=str(self.project_root/t.task_id); self.storage.save(t)
            elif not t.project_dir:
                t.project_dir=str(self.project_root/t.task_id); t.total_steps=len(t.plan); self.storage.save(t)
            project_path=Path(t.project_dir).expanduser(); project_path=project_path if project_path.is_absolute() else self.root/project_path
            term=Terminal(project_path); term.policy.path('.').mkdir(parents=True,exist_ok=True)
            for i in range(t.current_step,len(t.plan)):
                if self.cancel_requested(t): self.state(t,'CANCELLED' if t.control=='CANCEL' else 'PAUSED','Stopped safely'); self.storage.checkpoint(t); return t
                if time.time()-started>t.max_runtime_seconds: t.last_error='Maximum runtime exceeded'; self.state(t,'FAILED','Runtime limit reached'); self.storage.checkpoint(t); return t
                step=t.plan[i]; t.current_step=i+1; self.emit(t,'step_started',step=t.current_step,title=step.get('title',''))
                if step.get('kind')=='write':
                    self.state(t,'RUNNING','Creating '+step.get('path','file')); content=step.get('content',''); mode=term.write(step['path'],content); (t.files_created if mode=='created' else t.files_modified).append(step['path']); self.emit(t,'file_written',path=step['path'],mode=mode)
                else:
                    self.state(t,'TESTING','Running '+step.get('command',''))
                    approval=self.storage.get_approval(t.task_id)
                    try:
                        result=term.run(step['command'],allow_approval=bool(approval and approval.get('decision')=='APPROVED'),cancel=lambda:self.cancel_requested(t))
                    except SecurityError as exc:
                        t.current_step-=1; self.storage.approval(t.task_id,step['command'],str(exc),str(self.root/t.project_dir)); self.storage.checkpoint(t); self.state(t,'WAITING_APPROVAL','Approval required'); return t
                    t.commands.append(result); t.last_command=step['command']; self.emit(t,'command_finished',**result)
                    if result.get('cancelled'): self.state(t,'CANCELLED' if t.control=='CANCEL' else 'PAUSED','Command stopped'); self.storage.checkpoint(t); return t
                    if result['exit_code']:
                        self.state(t,'DEBUGGING','Analyzing error'); t.last_error=self.analyzer.analyze(result)['summary']; t.retry_count+=1; self.storage.checkpoint(t); self.emit(t,'error_detected',error=t.last_error,retry=t.retry_count)
                        if t.retry_count>t.max_iterations: self.state(t,'FAILED','Maximum repair iterations reached'); return t
                        fix=self.fixer.fix(self.analyzer.analyze(result),term,t); self.emit(t,'fix_attempted',**fix)
                        if not fix['fixed']: self.state(t,'FAILED','No safe repair available'); return t
                        self.state(t,'TESTING','Testing again'); retry=term.run(step['command'],cancel=lambda:self.cancel_requested(t)); t.commands.append(retry); self.emit(t,'retry_finished',**retry)
                        if retry.get('cancelled'): self.state(t,'CANCELLED','Retry stopped'); return t
                        if retry['exit_code']: t.last_error=retry['stderr'] or retry['stdout']; self.state(t,'FAILED','Repair did not pass verification'); return t
                        t.last_error=''
            self.state(t,'COMPLETED','Final QA'); self.storage.checkpoint(t); self.emit(t,'qa_complete',result=QA().final(t)); self.storage.report(t); return t
        except Exception as exc:
            t.last_error=str(exc); self.state(t,'FAILED','Unhandled worker error'); self.storage.checkpoint(t); self.storage.report(t); return t
        finally: self.storage.save(t); self.storage.report(t); self.active.pop(t.task_id,None)
    def request_control(self,task_id,control):
        t=self.storage.load(task_id); t.control=control; self.storage.save(t)
        active=self.active.get(task_id)
        if active is not None: active.control=control
        self.emit(t,'control_requested',control=control); return t
    def resume_task(self,task_id):
        t=self.storage.load(task_id); t.control='RUN'; t.status='QUEUED'; self.storage.save(t); self.storage.enqueue(task_id); return t
