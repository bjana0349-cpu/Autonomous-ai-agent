import json, threading, os, sqlite3, time
from pathlib import Path
from .models import now, TaskState
class Storage:
    def __init__(self, root):
        self.root=Path(root); self.lock=threading.RLock(); self.listeners=[]; self.db=self.root/'agent.sqlite3'
        for n in ('tasks','logs','checkpoints','memory','projects','reports'): (self.root/n).mkdir(parents=True,exist_ok=True)
        with self.conn() as c:
            c.execute('create table if not exists queue(task_id text primary key, priority integer default 0, queued_at text, owner text, lock_at real)')
            c.execute('create table if not exists approvals(task_id text primary key, command text, reason text, affected text, decision text, decided_at text, rejection_reason text)')
    def conn(self):
        c=sqlite3.connect(self.db,timeout=10); c.row_factory=sqlite3.Row; return c
    def save(self,t):
        t.updated_at=now(); tmp=self.task_path(t.task_id).with_suffix('.tmp'); tmp.write_text(json.dumps(t.to_dict(),indent=2)); os.replace(tmp,self.task_path(t.task_id))
        with self.conn() as c:
            row=c.execute('select priority,queued_at,owner,lock_at from queue where task_id=?',(t.task_id,)).fetchone()
            if row: c.execute('update queue set priority=?,queued_at=?,owner=?,lock_at=? where task_id=?',(row['priority'],row['queued_at'],row['owner'],row['lock_at'],t.task_id))
    def task_path(self,i): return self.root/'tasks'/(i+'.json')
    def load(self,i): return TaskState.from_dict(json.loads(self.task_path(i).read_text()))
    def list_tasks(self): return [TaskState.from_dict(json.loads(p.read_text())) for p in sorted((self.root/'tasks').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)]
    def enqueue(self,i,priority=0):
        with self.conn() as c: c.execute('insert or ignore into queue(task_id,priority,queued_at) values(?,?,?)',(i,priority,now()))
    def dequeue(self,owner='worker'):
        with self.conn() as c:
            c.execute('update queue set owner=null,lock_at=null where owner is not null and lock_at<?',(time.time()-120,))
            row=c.execute('select task_id from queue where owner is null order by priority desc,queued_at limit 1').fetchone()
            if not row: return None
            c.execute('update queue set owner=?,lock_at=? where task_id=? and owner is null',(owner,time.time(),row['task_id']))
            return row['task_id']
    def release(self,i):
        with self.conn() as c: c.execute('delete from queue where task_id=?',(i,))
    def recover_stale(self):
        with self.conn() as c: c.execute('update queue set owner=null,lock_at=null where owner is not null')
        for t in self.list_tasks():
            if t.status in ('PLANNING','RUNNING','TESTING','DEBUGGING') and t.control=='RUN': self.enqueue(t.task_id)
    def approval(self,task_id,command,reason,affected=''):
        with self.conn() as c: c.execute('insert or replace into approvals(task_id,command,reason,affected,decision) values(?,?,?,?,?)',(task_id,command,reason,affected,'PENDING'))
    def get_approval(self,task_id):
        with self.conn() as c:
            r=c.execute('select * from approvals where task_id=?',(task_id,)).fetchone(); return dict(r) if r else None
    def decide_approval(self,task_id,decision,rejection_reason=''):
        with self.conn() as c: c.execute('update approvals set decision=?,decided_at=?,rejection_reason=? where task_id=?',(decision,now(),rejection_reason,task_id))
    def log(self,i,event,**data):
        t=self.load(i) if self.task_path(i).exists() else None
        r={'timestamp':now(),'task_id':i,'event_type':event,'status':t.status if t else None,'step':t.current_step if t else None,'retry_count':t.retry_count if t else None,**data}
        with self.lock:
            with (self.root/'logs'/(i+'.jsonl')).open('a') as f: f.write(json.dumps(r)+'\n')
        for listener in list(self.listeners):
            try: listener(i,r)
            except Exception: pass
        return r
    def checkpoint(self,t): (self.root/'checkpoints'/(t.task_id+'.json')).write_text(json.dumps(t.to_dict(),indent=2))
    def report(self,t):
        report={'task':t.request,'task_id':t.task_id,'status':t.status,'start_time':t.started_at,'end_time':t.updated_at,'files_created':t.files_created,'files_modified':t.files_modified,'commands':t.commands,'errors':t.last_error,'retry_count':t.retry_count,'checkpoints_created':(self.root/'checkpoints'/(t.task_id+'.json')).exists(),'final_verification':t.status=='COMPLETED','project_location':str(self.root/t.project_dir),'remaining_issues':[] if t.status=='COMPLETED' else [t.last_error]}
        (self.root/'reports'/(t.task_id+'.json')).write_text(json.dumps(report,indent=2)); return report
