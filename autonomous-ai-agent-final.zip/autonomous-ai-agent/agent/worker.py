import threading,time,uuid
from .loop import AgentLoop
class Worker:
    def __init__(self,root,storage): self.root=root; self.storage=storage; self.loop=AgentLoop(root,storage); self.stop_event=threading.Event(); self.thread=None; self.owner='worker-'+uuid.uuid4().hex[:8]
    def start(self):
        self.storage.recover_stale()
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,name='agent-worker',daemon=True); self.thread.start()
    def _run(self):
        while not self.stop_event.is_set():
            task_id=self.storage.dequeue(self.owner)
            if not task_id: time.sleep(.2); continue
            try:
                task=self.storage.load(task_id)
                if task.status in ('COMPLETED','FAILED','CANCELLED'): continue
                self.loop.run(task)
            except Exception as exc: self.storage.log(task_id,'worker_error',error=str(exc))
            finally: self.storage.release(task_id)
    def stop(self): self.stop_event.set()
