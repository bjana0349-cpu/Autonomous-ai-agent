from dataclasses import dataclass, field, asdict
import os
from datetime import datetime, timezone
import uuid

STATES = ('QUEUED','PLANNING','RUNNING','TESTING','DEBUGGING','WAITING_APPROVAL','COMPLETED','FAILED','CANCELLED','PAUSED')
def now(): return datetime.now(timezone.utc).isoformat()
@dataclass
class TaskState:
    task_id: str; request: str; status: str='QUEUED'; current_step: int=0; total_steps: int=0
    retry_count: int=0; max_iterations: int=5; max_runtime_seconds: int=3600
    last_command: str=''; last_error: str=''; current_action: str=''; started_at: str=''
    files_created: list=field(default_factory=list); files_modified: list=field(default_factory=list)
    commands: list=field(default_factory=list); events: list=field(default_factory=list); plan: list=field(default_factory=list)
    project_dir: str=''; control: str='RUN'; created_at: str=field(default_factory=now); updated_at: str=field(default_factory=now)
    @classmethod
    def new(cls, request, task_id=None):
        return cls(task_id or 'task_'+uuid.uuid4().hex[:10], request, max_iterations=int(os.getenv('MAX_TASK_ITERATIONS','5')), max_runtime_seconds=int(os.getenv('MAX_TASK_RUNTIME','3600')))
    def to_dict(self): return asdict(self)
    @classmethod
    def from_dict(cls, data):
        data=dict(data); data.setdefault('control','RUN'); data.setdefault('current_action',''); data.setdefault('started_at',''); data.setdefault('max_runtime_seconds',3600); return cls(**data)
