# Autonomous AI Coding & Task Assistant — Production-Hardening MVP

Standalone Python-first coding worker for Linux and Android Termux. The current version adds model-backed planning/repair, a SQLite-backed persistent queue, worker ownership and stale-lock recovery, approval-gated commands, checkpoints, structured JSONL observability, persistent final reports, pause/resume/cancel controls, SSE updates, and a hardened Termux bridge.

## Android Termux

For Android installation, use the dedicated [Termux deployment guide](TERMUX.md). It covers `$HOME`-relative paths, package installation, `.env`, workspace initialization, worker/dashboard/bridge startup, task controls, restart recovery, bridge security, and Termux limitations. The helper scripts are in `termux/`.

## Quick start

```bash
cd ~/autonomous-ai-agent
python3 -m compileall -q .
python3 main.py self-test
python3 main.py dashboard --host 0.0.0.0 --port 8080
```

The dashboard creates tasks asynchronously. Start the independent worker when running without the dashboard:

```bash
python3 main.py worker
```

CLI controls:

```bash
python3 main.py submit "Build me a professional grocery store website"
python3 main.py pause task_abc123
python3 main.py resume task_abc123
python3 main.py stop task_abc123
python3 main.py retry task_abc123
python3 main.py status task_abc123
python3 main.py recover
```

## Architecture and security

`agent/planner.py` contains the configurable OpenAI-compatible model adapter. `agent/fixer.py` sends concise error context and relevant files and expects structured JSON edits. `agent/loop.py` implements bounded plan/execute/test/debug/retest/checkpoint/QA behavior and approval pauses. `agent/worker.py` is an independent long-running queue consumer. `agent/storage.py` uses SQLite transactions for queue rows, worker ownership, stale locks, approvals, tasks, checkpoints, JSONL logs, and final reports. `agent/security.py` classifies commands as SAFE, RESTRICTED, or DANGEROUS and confines paths to the configured workspace.

Supported lifecycle states are `QUEUED`, `PLANNING`, `RUNNING`, `TESTING`, `DEBUGGING`, `WAITING_APPROVAL`, `COMPLETED`, `FAILED`, `CANCELLED`, and `PAUSED`.

Generated projects use `AGENT_PROJECT_ROOT`; application data uses `AGENT_DATA_ROOT`. Defaults remain compatible with the original local layout when these variables are absent.

## Model and cost controls

```bash
export OPENAI_API_KEY="..."
export OPENAI_API_BASE="https://api.openai.com/v1"
export AGENT_MODEL="gpt-5-mini"
```

See `.env.example` for all path, binding, retry, runtime, and context variables.

## Approval workflow

Restricted or dangerous commands pause execution in `WAITING_APPROVAL`. The dashboard displays the command, reason, affected path, and Approve/Reject controls. Approval resumes the task; rejection records the reason and safely cancels it.

## Persistence and reports

- `AGENT_DATA_ROOT/agent.sqlite3` — queue, ownership locks, approvals, and timestamps
- `AGENT_DATA_ROOT/tasks/` — durable task state and plan
- `AGENT_DATA_ROOT/logs/` — structured JSONL events
- `AGENT_DATA_ROOT/checkpoints/` — safe snapshots
- `AGENT_DATA_ROOT/reports/` — final task reports
- `AGENT_PROJECT_ROOT/TASK_ID/` — isolated generated workspaces

The system is a hardened production-oriented MVP. Android battery suspension, model/API failures, and single-worker SQLite limits remain real deployment considerations.

## Jarvis Android voice assistant

The native Kotlin Android module is in `android-jarvis/`. Read [JARVIS.md](JARVIS.md) for the existing-stack integration, wake-word/voice behavior, permissions, foreground microphone-service declaration, backend connection, build instructions, owner-safety policy, and explicitly untested device-dependent behavior.
