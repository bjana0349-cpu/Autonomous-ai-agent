# Jarvis Android Voice Assistant

Jarvis is an Android module inside the existing `autonomous-ai-agent` repository. It is not a separate agent. The Python worker, SQLite queue, dashboard, bridge security policy, approvals, logs, checkpoints, and recovery remain the system of record.

## Existing stack

- Python 3 worker and planner
- SQLite durable queue and JSON task/report/checkpoint files
- Local HTTP dashboard with task controls and SSE events
- Authenticated, workspace-confined Termux bridge
- OpenAI-compatible model adapter for planning and repair

## Android module

Path:

```text
android-jarvis/
```

The native Kotlin app provides:

- Start/Stop Listening controls
- Foreground microphone service declaration
- Persistent low-importance microphone notification
- `Jarvis` wake-word gate
- Exact activation phrase: `Hi Biswajit, ami ki bhabe sahajjo korte pari?`
- Android speech recognition and Text-to-Speech
- Bengali/Banglish/Hindi/English free-form recognition through the installed recognizer
- Speech interruption control
- Existing dashboard API task submission and status polling
- Conversation history and backend URL settings
- Device permission request flow
- Explicit warning that voice matching is not authentication

Voice commands do not run shell commands. They submit natural-language tasks to the existing agent API, whose command policy and approval workflow remain authoritative.

## Backend on the phone

Run the existing backend in Termux:

```bash
cd "$HOME/autonomous-ai-agent"
bash termux/start-worker.sh
bash termux/start-dashboard.sh
```

Set the Android app backend URL to:

```text
http://127.0.0.1:8080
```

If the backend is on another computer, use that computer's secured URL instead. Do not expose the bridge or API directly to the public internet.

## Build prerequisites

The current sandbox does not include Gradle, Android SDK, ADB, or `javac`, so no APK was built or device-tested here. Build on a machine with Android Studio or the Android command-line tools:

```bash
cd autonomous-ai-agent/android-jarvis
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
gradle :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

If `gradle` is not installed, open `android-jarvis` in Android Studio and use **Build > Make Project**, then **Build > Build APK(s)**.

## First Android test

1. Install the debug APK.
2. Grant microphone permission.
3. Grant notification permission.
4. Disable battery optimization for Jarvis/Termux during testing.
5. Start the Termux worker and dashboard.
6. Set backend URL to `http://127.0.0.1:8080`.
7. Tap **Start Listening**.
8. Say `Jarvis`.
9. Confirm the exact Bengali greeting is spoken.
10. Say `create a website`.
11. Confirm a task appears in the existing dashboard and the app reports task status.
12. Turn the screen off and verify the persistent notification and microphone listening behavior on the target phone.

Screen-off listening is **not claimed as tested** in this environment. It requires a real Android device test because OEM battery restrictions, microphone policy, speech recognizer behavior, and foreground-service rules vary by device.

## Permissions and paid/API requirements

- `RECORD_AUDIO`: required for speech recognition.
- `POST_NOTIFICATIONS`: required on Android 13+ for the visible foreground-service notification.
- `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MICROPHONE`: required for microphone foreground service.
- Battery optimization exemption: recommended for reliable background behavior; the user must grant it in Android settings.
- `OPENAI_API_KEY`: required only when the existing backend needs the configured model provider.
- Android speech recognition and Text-to-Speech may use device services; availability/language quality depends on the installed Android provider.
- No API key is embedded in the APK.

## Owner recognition and sensitive actions

The app explicitly does not treat voice matching as secure authentication. A production speaker-verification model is not bundled yet. Sensitive actions must use device authentication/confirmation and still pass the existing agent approval workflow. The current voice path only submits tasks; it cannot bypass the bridge's workspace confinement or command policy.

## Current test boundary

Static source and configuration checks are possible in the sandbox. A real APK build, microphone test, wake-word test, screen-off test, multilingual speech-quality test, battery test, and device-authentication test require Android SDK tooling and a target Android device. Those are intentionally reported as untested rather than claimed complete.

For Termux build diagnostics and the reproducible cloud APK workflow, see [JARVIS_BUILD.md](JARVIS_BUILD.md). The repository also includes `.github/workflows/android-jarvis.yml` and `termux/diagnose-android-build.sh`.
