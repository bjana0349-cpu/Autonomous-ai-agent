import json,os,secrets,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from agent.terminal import Terminal
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def send_json(self,c,o):
        x=json.dumps(o).encode(); self.send_response(c); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(x))); self.end_headers(); self.wfile.write(x)
    def do_POST(self):
        if self.headers.get('Authorization')!='Bearer '+self.server.token: return self.send_json(401,{'error':'unauthorized'})
        try:
            b=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}'); op=b.get('op'); t=self.server.term
        except Exception as e: return self.send_json(400,{'error':str(e)})
        try:
            if op=='register': out={'registered':True,'workspace':str(t.policy.workspace)}
            elif op=='heartbeat': self.server.last_heartbeat=time.time(); out={'ok':True,'time':self.server.last_heartbeat}
            elif op=='status': out={'workspace':str(t.policy.workspace),'heartbeat':self.server.last_heartbeat}
            elif op=='write': out={'result':t.write(b['path'],b['content'])}
            elif op=='read': out={'content':t.read(b['path'])}
            elif op=='delete': out={'result':t.delete(b['path'])}
            elif op=='exec': out=t.run(b['command'],b.get('cwd','.'),allow_restricted=bool(b.get('approved')))
            else: return self.send_json(400,{'error':'unsupported operation'})
            self.send_json(200,out)
        except Exception as e: self.send_json(400,{'error':str(e)})
def serve(w,host='127.0.0.1',port=8765,token=None):
    s=ThreadingHTTPServer((host,port),H); s.token=token or os.getenv('BRIDGE_TOKEN') or secrets.token_urlsafe(24); s.term=Terminal(w); s.last_heartbeat=0; print(f'Bridge listening on {host}:{port}\nBRIDGE_TOKEN={s.token}',flush=True); s.serve_forever()
