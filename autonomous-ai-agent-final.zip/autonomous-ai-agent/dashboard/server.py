import json,time,os
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from agent.storage import Storage
from agent.models import TaskState
from agent.worker import Worker
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def send_json(self,code,obj):
        raw=json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        if self.path=='/api/tasks': return self.send_json(200,[t.to_dict() for t in self.server.storage.list_tasks()])
        if self.path.startswith('/api/tasks/') and self.path.endswith('/approval'):
            return self.send_json(200,self.server.storage.get_approval(self.path.split('/')[3]) or {})
        if self.path.startswith('/api/tasks/') and self.path.endswith('/events'):
            tid=self.path.split('/')[3]; self.send_response(200); self.send_header('Content-Type','text/event-stream'); self.send_header('Cache-Control','no-cache'); self.end_headers()
            log=self.server.data_root/'logs'/(tid+'.jsonl'); pos=0
            for _ in range(40):
                if log.exists():
                    text=log.read_text(); chunk=text[pos:]; pos=len(text)
                    for line in chunk.splitlines(): self.wfile.write(('data: '+line+'\n\n').encode())
                self.wfile.flush(); time.sleep(.5)
            return
        p=self.server.root/'dashboard/index.html'; raw=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_POST(self):
        try: body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}')
        except Exception as e: return self.send_json(400,{'error':str(e)})
        try:
            if self.path=='/api/tasks':
                t=TaskState.new(body.get('request','')); self.server.storage.save(t); self.server.storage.enqueue(t.task_id); return self.send_json(202,{'task_id':t.task_id,'status':t.status})
            parts=self.path.strip('/').split('/'); tid=parts[2] if len(parts)>=3 else ''; action=parts[3] if len(parts)>=4 else ''
            if action in ('stop','pause'):
                t=self.server.worker.loop.request_control(tid,'CANCEL' if action=='stop' else 'PAUSE'); return self.send_json(200,t.to_dict())
            if action=='resume': return self.send_json(202,self.server.worker.loop.resume_task(tid).to_dict())
            if action=='approve':
                self.server.storage.decide_approval(tid,'APPROVED'); t=self.server.worker.loop.resume_task(tid); return self.send_json(202,t.to_dict())
            if action=='reject':
                t=self.server.storage.load(tid); self.server.storage.decide_approval(tid,'REJECTED',body.get('reason','')); t.control='CANCEL'; t.status='CANCELLED'; self.server.storage.save(t); self.server.storage.log(tid,'approval_rejected',reason=body.get('reason','')); return self.send_json(200,t.to_dict())
            if action=='retry':
                t=self.server.storage.load(tid); t.retry_count=0; t.last_error=''; t.control='RUN'; t.status='QUEUED'; self.server.storage.save(t); self.server.storage.enqueue(tid); return self.send_json(202,t.to_dict())
            return self.send_json(404,{'error':'not found'})
        except Exception as e: return self.send_json(400,{'error':str(e)})
def serve(root,host='0.0.0.0',port=8080,data_root=None):
    s=ThreadingHTTPServer((host,port),H); s.root=Path(root); s.data_root=Path(data_root or root).expanduser(); s.storage=Storage(s.data_root); s.worker=Worker(Path(root),s.storage)
    if os.getenv('AGENT_DASHBOARD_START_WORKER','1') != '0': s.worker.start()
    print(f'Dashboard listening on http://{host}:{port}',flush=True); s.serve_forever()
